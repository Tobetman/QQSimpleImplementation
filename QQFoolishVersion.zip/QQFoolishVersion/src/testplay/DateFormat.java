package testplay;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateFormat {

	public static void main(String[] args) throws ParseException {
		Date date = new Date();
		System.out.println(date);
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy��MM��dd��  HH:mm:ss");
		String str = dateFormat.format(date);
		System.out.println("��ǰʱ�䣺" + str);
		
		String str2 ="2020��05��22��  17:55:30";
		Date date2 = dateFormat.parse(str2);
		System.out.println(date2);

	}

}
