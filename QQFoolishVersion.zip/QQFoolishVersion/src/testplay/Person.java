package testplay;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;


public class Person implements Comparable<Person> {
	
		private String name;//����
		private int age;//����
		
		public Person(String name,int age) {
			this.name = name;
			this.age = age;
		}

		@Override
		public int compareTo(Person o) {
			int i = -1 * (this.age - o.age);
			return i;
		}
		
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public int getAge() {
			return age;
		}
		public void setAge(int age) {
			this.age = age;
		}
			

	public static void main(String[] args) {
		List<Person> persons= new ArrayList<Person>();
		int ageThreshold = 10;
		
		persons.add(new Person("name1",16));
		persons.add(new Person("name2",12));
		persons.add(new Person("name3",18));
		persons.add(new Person("name4",20));
		
		
		Collections.sort(persons);//��С��������
		
		List<Person> group1= new ArrayList<Person>();
		List<Person> group2= new ArrayList<Person>();
		
		Iterator<Person> it = persons.iterator();
		while(it.hasNext()) {
			Person temp = it.next();
			if(temp.getAge() > ageThreshold) {
				group1.add(temp);
			}else {
				group2.add(temp);
			}
		}
	}
}
