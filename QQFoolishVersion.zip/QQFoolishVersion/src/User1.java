import java.net.DatagramSocket;
import java.net.InetAddress;

public class User1 {

	public static void main(String[] args) throws Exception{
		UsersInformation User1 = new UsersInformation(1000,"Jerry","192.168.0.106",8000);//Jerry������Ϣ
		UsersInformation User2 = new UsersInformation(1001,"Tom","192.168.0.102",5000);//Tom������Ϣ
		DatagramSocket ds = new DatagramSocket(User1.getPort());//Jerry�˿ں�Ϊ8000
		System.out.println("=========Jerry��Tom�����촰��============");
		Communication.sendMsg(ds,InetAddress.getByName(User2.getIp()), User2.getPort(),
				User1.getName(), User2.getName());
		Communication.receiveMsg(ds,User2.getName());
	}
}