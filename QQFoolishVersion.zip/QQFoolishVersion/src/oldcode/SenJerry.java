package oldcode;
import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class SenJerry {

	public static void main(String[] args) throws Exception{
		DatagramSocket ds = new DatagramSocket(8000);//Tom�˿ں�Ϊ8000
		System.out.println("=========Jerry��Tom�����촰��============");
		new Thread(new Runnable() {//�½��߳�ʵ�ַ�����Ϣ
			public void run() {
				while(true) {
					String strSend = getString();
					if(strSend == "") {
						continue;
					}
					byte [] buf = strSend.getBytes();
					try {
						DatagramPacket dp2 = new DatagramPacket(buf,buf.length,
								InetAddress.getByName("127.0.0.1"),5000);
						ds.send(dp2);
						System.out.println("���ʹ�");
					} catch (UnknownHostException e) {
						e.printStackTrace();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		}).start();
		
		byte [] buf2 = new byte[1000];//main�����ʵ�ֽ���
		DatagramPacket dp = new DatagramPacket(buf2,buf2.length);//���հ�װ
		while(true) {
			ds.receive(dp);
			String Recv = new String(dp.getData(),0,dp.getLength());
			String strRecv = "Tom: "+ Recv;
			System.out.println("��������Ϣ��");
			System.out.println(strRecv);
			if (Recv == "Goodbye") {
				break;
			}
		}
		ds.close();
	}
	
	public static String getString() {//�Ӽ��̻���ַ���
		String send = "";
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		send = sc.nextLine();
		return send;
	}
}

