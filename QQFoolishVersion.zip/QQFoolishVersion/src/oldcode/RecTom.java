package oldcode;
import java.io.IOException;
import java.net.*;
import java.util.Scanner;
import java.util.Calendar;

public class RecTom {

	public static void main(String[] args) throws Exception{
		DatagramSocket ds = new DatagramSocket(5000);//Tom�˿ں�Ϊ5000
		System.out.println("=========Tom��Jerry�����촰��============");
		sendMsg(ds,InetAddress.getByName("127.0.0.1"), 8000, "Tom", "Jerry");
		receiveMsg(ds,"Jerry");
	}
	
	public static void receiveMsg(DatagramSocket ds, String from) throws Exception {
		byte [] buf2 = new byte[1000];
		DatagramPacket dp = new DatagramPacket(buf2,buf2.length);//���հ�װ
		while(true) {
			ds.receive(dp);
			String strRecv = new String(dp.getData(),0,dp.getLength());
			printout(from,strRecv);
		}
	}
	
	public static void sendMsg(DatagramSocket ds, InetAddress IA, int port, String sender, String receiver) {
		new Thread(new Runnable() {//�½��߳�ʵ�ַ�����Ϣ
			public void run() {
				while(true) {
					String strSend = getString();
					if(strSend == "") {
						continue;
					}
					byte [] buf = strSend.getBytes();
					//System.out.println("Tom: " + strSend);
					try {
						DatagramPacket dp2 = new DatagramPacket(buf,buf.length,
								//InetAddress.getByName("192.168.0.102"),8000);
								IA,port);
						ds.send(dp2);
						//System.out.println(dp2.toString());
						System.out.println("�����������ʹ������");
						printout(sender,strSend);
					} catch (UnknownHostException e) {
						e.printStackTrace();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		}).start();
	}
	
	public static String getString() {//�Ӽ��̻���ַ���
		String send = "";
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		send = sc.nextLine();
		return send;
	}
	
	public static void printout(String name,String Msg) {//�Ի��������������
		System.out.println(name + "  " + getCurrentTime());
		System.out.println(Msg);
	}
	
	public static String getCurrentTime() {//��ȡ��ǰʱ��
		Calendar calendar = Calendar.getInstance();
		int hour = calendar.get(Calendar.HOUR_OF_DAY);
		int minute = calendar.get(Calendar.MINUTE);
		int second = calendar.get(Calendar.SECOND);
		String time = hour + ":" + minute + ":" + second;
		return time;
	}
	
}
