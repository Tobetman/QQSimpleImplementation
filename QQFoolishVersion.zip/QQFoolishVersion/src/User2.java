import java.net.DatagramSocket;
import java.net.InetAddress;

public class User2 {

	public static void main(String[] args) throws Exception{
		UsersInformation User1 = new UsersInformation(1000,"Jerry","127.0.0.1",8000);//Jerry������Ϣ
		UsersInformation User2 = new UsersInformation(1001,"Tom","127.0.0.1",5000);//Tom������Ϣ
		DatagramSocket ds = new DatagramSocket(User2.getPort());//Tom�˿ں�Ϊ8000
		System.out.println("=========Tom��Jerry�����촰��============");
		Communication.sendMsg(ds,InetAddress.getByName(User1.getIp()), User1.getPort(),
				User2.getName(), User1.getName());
		Communication.receiveMsg(ds,User1.getName());
	}
}